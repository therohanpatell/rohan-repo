#!/usr/bin/env python3
"""
generate_synthetic.py
=====================================================================
Generic synthetic data generator for BigQuery SOURCE tables.

Given a folder of BigQuery schema JSON files (the standard
`bq show --schema --format=prettyjson` output) plus a small
relationships.json config, it generates one CSV per schema that is
directly loadable into BigQuery.

Features
--------
* Referential integrity across any number of tables (FK -> PK).
* Topological generation order (parents before children) with cycle
  detection. Handles chains and diamonds (multiple tables sharing a
  parent).
* Every parent is guaranteed at least one child (when child_rows >=
  parent_rows).
* Faker-based, field-name-aware value generation with type fallback.
* Reproducible via --seed.
* N-day "slice" mode: the same business keys are repeated across N
  days; one eligible (non-key, non-FK, non-audit) column changes each
  day. Date-like audit columns (pipeline_*) auto-advance +1 day per
  slice; non-date audit constants stay fixed.
* Audit columns (prefix configurable, default "pipeline_") are kept in
  their original DDL position and filled from config constants.
* Null control: --null-threshold for NULLABLE fields, or
  --null-mode all-non-null.
* CSV columns always emitted in exact DDL order; BigQuery-loadable
  formatting (empty cell = NULL, lowercase booleans, JSON strings for
  nested/repeated fields).

Usage
-----
    python generate_synthetic.py \
        --schemas ./schemas \
        --config relationships.json \
        --out ./out \
        --days 2 \
        --seed 42 \
        --null-threshold 0.1
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import random
import sys
import uuid
from datetime import datetime, timedelta, date
from typing import Any, Dict, List, Optional, Tuple

try:
    from faker import Faker
except ImportError:
    sys.exit("Faker is required. Install with: pip install faker")


# ---------------------------------------------------------------------------
# Constants / defaults
# ---------------------------------------------------------------------------

AUDIT_PREFIX_DEFAULT = "pipeline_"
DEFAULT_ROWS = 100
DATE_FMT = "%Y-%m-%d"
DATETIME_FMT = "%Y-%m-%d %H:%M:%S"
TIMESTAMP_FMT = "%Y-%m-%d %H:%M:%S UTC"
TIME_FMT = "%H:%M:%S"

# field-name keywords -> faker callables (checked as substrings, longest first)
NAME_HINTS = [
    ("email", lambda f: f.email()),
    ("first_name", lambda f: f.first_name()),
    ("last_name", lambda f: f.last_name()),
    ("full_name", lambda f: f.name()),
    ("username", lambda f: f.user_name()),
    ("user_name", lambda f: f.user_name()),
    ("company", lambda f: f.company()),
    ("department", lambda f: random.choice(
        ["HR", "Finance", "Engineering", "Sales", "Marketing", "Operations"])),
    ("dept", lambda f: random.choice(
        ["HR", "Finance", "Engineering", "Sales", "Marketing", "Operations"])),
    ("job_title", lambda f: f.job()),
    ("job", lambda f: f.job()),
    ("title", lambda f: f.job()),
    ("address", lambda f: f.address().replace("\n", ", ")),
    ("street", lambda f: f.street_address()),
    ("postal", lambda f: f.postcode()),
    ("zip", lambda f: f.postcode()),
    ("city", lambda f: f.city()),
    ("state", lambda f: f.state()),
    ("country", lambda f: f.country()),
    ("currency", lambda f: f.currency_code()),
    ("phone", lambda f: f.phone_number()),
    ("mobile", lambda f: f.phone_number()),
    ("name", lambda f: f.name()),  # generic name, kept late so *_name hits first
]

STATUS_VALUES = ["ACTIVE", "INACTIVE", "PENDING", "CLOSED", "SUSPENDED"]
TYPE_VALUES = ["STANDARD", "PREMIUM", "BASIC", "ENTERPRISE"]


# ---------------------------------------------------------------------------
# Schema / config loading
# ---------------------------------------------------------------------------

def load_schemas(schemas_dir: str) -> Dict[str, List[dict]]:
    """Load every *.json in the schemas dir. Table name = filename stem."""
    schemas: Dict[str, List[dict]] = {}
    if not os.path.isdir(schemas_dir):
        sys.exit(f"Schemas dir not found: {schemas_dir}")
    for fn in sorted(os.listdir(schemas_dir)):
        if not fn.lower().endswith(".json"):
            continue
        table = os.path.splitext(fn)[0]
        with open(os.path.join(schemas_dir, fn), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, list):
            sys.exit(f"Schema {fn} must be a JSON array of field objects.")
        schemas[table] = data
    if not schemas:
        sys.exit(f"No .json schema files found in {schemas_dir}")
    return schemas


def load_config(config_path: str) -> dict:
    if not os.path.isfile(config_path):
        sys.exit(f"Config file not found: {config_path}")
    with open(config_path, "r", encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# FK graph + topological sort
# ---------------------------------------------------------------------------

def parse_fk(ref: str) -> Tuple[str, str]:
    """'orders.customer_id' -> ('orders', 'customer_id')"""
    if "." not in ref:
        sys.exit(f"FK reference must be 'table.column', got: {ref}")
    t, c = ref.split(".", 1)
    return t, c


def build_fk_map(config: dict) -> Dict[str, List[dict]]:
    """table -> list of {column, ref_table, ref_column}."""
    fk_map: Dict[str, List[dict]] = {}
    for fk in config.get("foreign_keys", []):
        ct, cc = parse_fk(fk["from"])
        pt, pc = parse_fk(fk["to"])
        fk_map.setdefault(ct, []).append(
            {"column": cc, "ref_table": pt, "ref_column": pc})
    return fk_map


def topo_sort(tables: List[str], fk_map: Dict[str, List[dict]]) -> List[str]:
    """Return tables ordered so parents come before children. Detect cycles."""
    # dependency: child depends on parent
    deps: Dict[str, set] = {t: set() for t in tables}
    for child, fks in fk_map.items():
        for fk in fks:
            if fk["ref_table"] in deps and fk["ref_table"] != child:
                deps[child].add(fk["ref_table"])

    ordered: List[str] = []
    visited: Dict[str, int] = {}  # 0=visiting, 1=done

    def visit(node: str, stack: List[str]):
        state = visited.get(node)
        if state == 1:
            return
        if state == 0:
            cycle = " -> ".join(stack + [node])
            sys.exit(f"Cycle detected in foreign keys: {cycle}. "
                     "Break the cycle or make one FK nullable + remove it "
                     "from config.")
        visited[node] = 0
        for dep in sorted(deps[node]):
            visit(dep, stack + [node])
        visited[node] = 1
        ordered.append(node)

    for t in tables:
        visit(t, [])
    return ordered


# ---------------------------------------------------------------------------
# Value generation
# ---------------------------------------------------------------------------

class ValueFactory:
    def __init__(self, faker: Faker, base_date: date):
        self.f = faker
        self.base_date = base_date
        self._seq: Dict[str, int] = {}

    def next_seq(self, key: str) -> int:
        self._seq[key] = self._seq.get(key, 0) + 1
        return self._seq[key]

    # -- identifier helpers -------------------------------------------------
    def make_id(self, table: str, column: str, row_index: int) -> str:
        """Stable, unique-ish id for PK columns."""
        prefix = "".join([p[0] for p in table.split("_")][:3]).upper() or "ID"
        return f"{prefix}{row_index:06d}"

    # -- main entry ---------------------------------------------------------
    def value_for(self, field: dict, table: str, row_index: int) -> Any:
        name = field["name"].lower()
        ftype = field["type"].upper()

        # Enum-ish by name
        if name == "status" or name.endswith("_status"):
            return random.choice(STATUS_VALUES)
        if name == "type" or name.endswith("_type"):
            return random.choice(TYPE_VALUES)
        if name.startswith("is_") or name.startswith("has_") or name.endswith("_flag"):
            return random.choice([True, False])

        if ftype in ("STRING",):
            return self._string_value(name)
        if ftype in ("INTEGER", "INT64", "INT"):
            return self._int_value(name)
        if ftype in ("FLOAT", "FLOAT64", "NUMERIC", "BIGNUMERIC", "DECIMAL"):
            return self._float_value(name)
        if ftype in ("BOOLEAN", "BOOL"):
            return random.choice([True, False])
        if ftype == "DATE":
            return self._rand_date()
        if ftype == "DATETIME":
            return self._rand_datetime(DATETIME_FMT)
        if ftype == "TIMESTAMP":
            return self._rand_datetime(TIMESTAMP_FMT)
        if ftype == "TIME":
            return self.f.time(pattern=TIME_FMT)
        if ftype == "BYTES":
            import base64
            return base64.b64encode(self.f.binary(length=8)).decode()
        # nested / unknown -> JSON string
        if ftype in ("RECORD", "STRUCT"):
            return json.dumps({"value": self.f.word()})
        return self.f.word()

    def _string_value(self, name: str) -> str:
        for hint, fn in NAME_HINTS:
            if hint in name:
                return fn(self.f)
        if "code" in name:
            return self.f.lexify("???").upper()
        if "desc" in name or "comment" in name or "note" in name:
            return self.f.sentence(nb_words=6)
        if "url" in name:
            return self.f.url()
        return self.f.word()

    def _int_value(self, name: str) -> int:
        if "age" in name:
            return random.randint(18, 75)
        if "year" in name:
            return random.randint(2018, 2025)
        if "qty" in name or "quantity" in name or "count" in name:
            return random.randint(1, 500)
        return random.randint(1, 100000)

    def _float_value(self, name: str) -> float:
        if any(k in name for k in ("amount", "price", "cost", "salary", "balance", "total")):
            return round(random.uniform(10, 100000), 2)
        if any(k in name for k in ("pct", "percent", "rate", "ratio")):
            return round(random.uniform(0, 100), 2)
        return round(random.uniform(0, 10000), 4)

    def _rand_date(self) -> str:
        d = self.base_date - timedelta(days=random.randint(0, 730))
        return d.strftime(DATE_FMT)

    def _rand_datetime(self, fmt: str) -> str:
        dt = datetime.combine(self.base_date, datetime.min.time()) \
            - timedelta(days=random.randint(0, 730),
                        seconds=random.randint(0, 86399))
        return dt.strftime(fmt)


# ---------------------------------------------------------------------------
# Audit handling
# ---------------------------------------------------------------------------

def is_audit(field_name: str, prefix: str) -> bool:
    return field_name.lower().startswith(prefix.lower())


def is_date_like_type(ftype: str) -> bool:
    return ftype.upper() in ("DATE", "DATETIME", "TIMESTAMP")


def audit_value(field: dict, audit_constants: dict, day_offset: int,
                base_date: date) -> Any:
    """Return the audit value for a field, advancing date-like ones by day."""
    name = field["name"]
    ftype = field["type"].upper()
    if is_date_like_type(ftype):
        d = base_date + timedelta(days=day_offset)
        if ftype == "DATE":
            return d.strftime(DATE_FMT)
        if ftype == "DATETIME":
            return datetime.combine(d, datetime.min.time())\
                .replace(hour=2).strftime(DATETIME_FMT)
        return datetime.combine(d, datetime.min.time())\
            .replace(hour=2).strftime(TIMESTAMP_FMT)
    # non-date audit column: use config constant, else a sensible default
    if name in audit_constants:
        return audit_constants[name]
    # default fallbacks by common audit name
    low = name.lower()
    if "batch" in low or "run" in low:
        return audit_constants.get(name, "BATCH_0001")
    if "source" in low and "system" in low:
        return audit_constants.get(name, "SOURCE_SYS")
    if "dml" in low:
        return "I"
    return audit_constants.get(name, "")


# ---------------------------------------------------------------------------
# Table generation
# ---------------------------------------------------------------------------

def eligible_vary_columns(schema: List[dict], pk: Optional[str],
                          fk_cols: set, audit_prefix: str) -> List[str]:
    """Columns eligible to vary across day-slices."""
    out = []
    for fld in schema:
        nm = fld["name"]
        if nm == pk:
            continue
        if nm in fk_cols:
            continue
        if is_audit(nm, audit_prefix):
            continue
        out.append(nm)
    return out


def generate_table(
    table: str,
    schema: List[dict],
    tcfg: dict,
    fk_map: Dict[str, List[dict]],
    generated: Dict[str, List[dict]],
    vf: ValueFactory,
    audit_constants: dict,
    audit_prefix: str,
    days: int,
    null_threshold: float,
    null_all_non_null: bool,
    base_date: date,
) -> List[dict]:
    pk = tcfg.get("pk")
    rows_target = int(tcfg.get("rows", DEFAULT_ROWS))
    table_days = int(tcfg.get("days", days))
    vary_col = tcfg.get("vary_column")  # optional explicit override

    fks = fk_map.get(table, [])
    fk_cols = {fk["column"] for fk in fks}

    # Determine vary column if N-day mode active
    if table_days > 1:
        eligibles = eligible_vary_columns(schema, pk, fk_cols, audit_prefix)
        if vary_col and vary_col not in eligibles:
            print(f"  [warn] vary_column '{vary_col}' not eligible for "
                  f"{table}; picking randomly.")
            vary_col = None
        if not vary_col:
            vary_col = random.choice(eligibles) if eligibles else None
        if vary_col is None:
            print(f"  [warn] {table}: no eligible column to vary; "
                  f"emitting day-slices with only audit dates advancing.")

    # --- build the base (day-1) business rows ---
    base_rows: List[dict] = []
    # FK assignment plan to guarantee >=1 child per parent (for each FK)
    fk_plans: Dict[str, List[Any]] = {}
    for fk in fks:
        parent_rows = generated.get(fk["ref_table"], [])
        parent_keys = [r[fk["ref_column"]] for r in parent_rows]
        if not parent_keys:
            print(f"  [warn] {table}.{fk['column']}: parent "
                  f"{fk['ref_table']} has no rows; FK left empty.")
            fk_plans[fk["column"]] = [None] * rows_target
            continue
        plan: List[Any] = []
        # guarantee coverage: one row per parent first
        if rows_target >= len(parent_keys):
            plan.extend(parent_keys)  # one of each
            remaining = rows_target - len(parent_keys)
            plan.extend(random.choice(parent_keys) for _ in range(remaining))
        else:
            print(f"  [warn] {table}: rows ({rows_target}) < parents "
                  f"({len(parent_keys)}) for FK {fk['column']}; not all "
                  f"parents will have a child.")
            plan.extend(random.sample(parent_keys, rows_target))
        random.shuffle(plan)
        fk_plans[fk["column"]] = plan

    pk_seen = set()
    for i in range(rows_target):
        row: Dict[str, Any] = {}
        for fld in schema:
            nm = fld["name"]
            mode = fld.get("mode", "NULLABLE").upper()

            # Audit column
            if is_audit(nm, audit_prefix):
                row[nm] = audit_value(fld, audit_constants, 0, base_date)
                continue
            # PK
            if nm == pk:
                pid = vf.make_id(table, nm, i + 1)
                while pid in pk_seen:  # safety
                    pid = vf.make_id(table, nm, i + 1 + len(pk_seen))
                pk_seen.add(pid)
                row[nm] = pid
                continue
            # FK
            if nm in fk_cols:
                row[nm] = fk_plans[nm][i]
                continue
            # Null injection (NULLABLE only, never REQUIRED)
            if (not null_all_non_null and mode == "NULLABLE"
                    and null_threshold > 0 and random.random() < null_threshold):
                row[nm] = None
                continue
            row[nm] = vf.value_for(fld, table, i + 1)
        base_rows.append(row)

    # --- expand into day-slices ---
    if table_days <= 1:
        return base_rows

    all_rows: List[dict] = []
    for day in range(table_days):
        for base in base_rows:
            r = dict(base)
            # advance date-like audit columns
            for fld in schema:
                if is_audit(fld["name"], audit_prefix):
                    r[fld["name"]] = audit_value(
                        fld, audit_constants, day, base_date)
            # change the varying column on days after day 0
            if day > 0 and vary_col is not None:
                fld = next(f for f in schema if f["name"] == vary_col)
                r[vary_col] = vf.value_for(fld, table, 0)
            all_rows.append(r)
    return all_rows


# ---------------------------------------------------------------------------
# CSV writing (BigQuery-loadable)
# ---------------------------------------------------------------------------

def to_cell(value: Any, field: dict) -> str:
    if value is None:
        return ""  # empty => NULL in BigQuery
    ftype = field["type"].upper()
    mode = field.get("mode", "NULLABLE").upper()
    if mode == "REPEATED" and not isinstance(value, str):
        return json.dumps(value)
    if ftype in ("BOOLEAN", "BOOL"):
        return "true" if value else "false"
    if ftype in ("RECORD", "STRUCT") and not isinstance(value, str):
        return json.dumps(value)
    return str(value)


def write_csv(out_dir: str, table: str, schema: List[dict],
              rows: List[dict]) -> str:
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{table}.csv")
    headers = [f["name"] for f in schema]  # exact DDL order
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, quoting=csv.QUOTE_MINIMAL)
        w.writerow(headers)
        for row in rows:
            w.writerow([to_cell(row.get(f["name"]), f) for f in schema])
    return path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="Generic synthetic data generator for BigQuery source tables.")
    ap.add_argument("--schemas", required=True, help="Dir of BQ schema JSONs.")
    ap.add_argument("--config", required=True, help="relationships.json path.")
    ap.add_argument("--out", default="./out", help="Output dir for CSVs.")
    ap.add_argument("--days", type=int, default=1,
                    help="Global day-slices (1 = no history). Per-table "
                         "override via config 'days'.")
    ap.add_argument("--seed", type=int, default=None, help="Reproducibility seed.")
    ap.add_argument("--null-threshold", type=float, default=0.0,
                    help="Fraction of NULLABLE fields set NULL (0..1).")
    ap.add_argument("--null-mode", choices=["default", "all-non-null"],
                    default="default")
    ap.add_argument("--audit-prefix", default=AUDIT_PREFIX_DEFAULT)
    args = ap.parse_args()

    if args.seed is not None:
        random.seed(args.seed)
        Faker.seed(args.seed)
    faker = Faker()

    config = load_config(args.config)
    schemas = load_schemas(args.schemas)
    tables_cfg = config.get("tables", {})
    audit_constants = config.get("audit_constants", {})

    # base date for day-slices & audit dates
    base_date_str = audit_constants.get("__base_date__")
    if base_date_str:
        base_date = datetime.strptime(base_date_str, DATE_FMT).date()
    else:
        # try to read from a configured pipeline_load_ts-like constant
        base_date = date.today()
        for k, v in audit_constants.items():
            if "load" in k.lower() and isinstance(v, str):
                try:
                    base_date = datetime.strptime(v[:10], DATE_FMT).date()
                    break
                except ValueError:
                    pass

    fk_map = build_fk_map(config)
    order = topo_sort(list(schemas.keys()), fk_map)

    print("Tables detected :", ", ".join(schemas.keys()))
    print("Generation order:", " -> ".join(order))
    if fk_map:
        print("Inferred FK links:")
        for child, fks in fk_map.items():
            for fk in fks:
                print(f"  {child}.{fk['column']} -> "
                      f"{fk['ref_table']}.{fk['ref_column']}")
    print(f"Base date       : {base_date}")
    print(f"Audit prefix    : {args.audit_prefix}")
    print()

    vf = ValueFactory(faker, base_date)
    generated: Dict[str, List[dict]] = {}
    written: List[str] = []

    for table in order:
        tcfg = tables_cfg.get(table, {})
        schema = schemas[table]
        audit_cols = [f["name"] for f in schema
                      if is_audit(f["name"], args.audit_prefix)]
        print(f"Generating {table} "
              f"(rows={tcfg.get('rows', DEFAULT_ROWS)}, "
              f"days={tcfg.get('days', args.days)})")
        if audit_cols:
            print(f"  audit columns (in-place): {', '.join(audit_cols)}")
        rows = generate_table(
            table, schema, tcfg, fk_map, generated, vf,
            audit_constants, args.audit_prefix,
            args.days, args.null_threshold,
            args.null_mode == "all-non-null", base_date,
        )
        generated[table] = rows
        path = write_csv(args.out, table, schema, rows)
        written.append(path)
        print(f"  -> {path}  ({len(rows)} rows)\n")

    print("Done. CSVs written:")
    for p in written:
        print(" ", p)
    print("\nLoad example:")
    print("  bq load --source_format=CSV --skip_leading_rows=1 \\")
    print("    project:dataset.<table> ./out/<table>.csv ./schemas/<table>.json")
    print("\nReminder: audit columns hold config constants / advanced dates. "
          "Override them in config 'audit_constants' or stamp at load time.")


if __name__ == "__main__":
    main()
