# Synthetic Data Generator for BigQuery Source Tables

Generates one CSV per BigQuery schema JSON, with cross-table referential
integrity, ready for `bq load`.

## Files
- `generate_synthetic.py` — the generator (single file, only dependency: `faker`).
- `relationships.json` — your per-run wiring (PKs, row counts, FKs, audit constants).
- `schemas/` — your BigQuery schema JSONs (one per table; filename = table name).
- `out/` — generated CSVs.

## Install & run
```bash
pip install faker
python generate_synthetic.py \
  --schemas ./schemas --config relationships.json --out ./out \
  --days 2 --seed 42 --null-threshold 0.1
```

## CLI flags
| Flag | Meaning | Default |
|---|---|---|
| `--schemas` | dir of BQ schema JSONs | required |
| `--config` | relationships.json | required |
| `--out` | output dir | `./out` |
| `--days` | day-slices: 1 = no history, 2 = two days, N = N days | 1 |
| `--seed` | reproducible output | none |
| `--null-threshold` | fraction of NULLABLE fields set to NULL (0..1) | 0.0 |
| `--null-mode` | `default` or `all-non-null` (force every field populated) | default |
| `--audit-prefix` | prefix that marks audit columns | `pipeline_` |

## relationships.json
```json
{
  "tables": {
    "employees": {
      "pk": ["company_id", "employee_id"],
      "rows": 1000,
      "unique": ["email"],
      "value_sets": {
        "company_id": ["CO_A", "CO_B"],
        "employee_status": ["ACTIVE", "ON_LEAVE", "TERMINATED"],
        "grade": ["G1", "G2", "G3", "G4"]
      },
      "copy_columns": { "gid": "employee_id" }
    },
    "assignments": {
      "pk": ["assignment_id"],
      "rows": 3000,
      "value_sets": { "project_code": ["PRJ-100", "PRJ-200", "PRJ-300"] }
    }
  },
  "foreign_keys": [
    { "from": ["assignments.company_id", "assignments.employee_id"],
      "to":   ["employees.company_id", "employees.employee_id"] }
  ],
  "audit_constants": {
    "__base_date__": "2024-03-01",
    "pipeline_source_system": "WORKDAY"
  }
}
```

### Per-table options
- **`pk`** — string **or list** of columns. A list = composite primary key;
  the *combination* is kept unique.
- **`rows`** — row count (1000–5000 fine). Parent/child ratio is implicit
  via the row counts you set.
- **`days`** — per-table override of `--days`.
- **`vary_column`** — pin which column changes across day-slices.
- **`unique`** — list of columns whose values must be distinct (enforced on
  the base rows, so N-day repeats don't break it).
- **`value_sets`** — column → allowed values. The column only ever draws from
  this list (overrides Faker).
- **`copy_columns`** — `{ "dest": "src" }`. `dest` always equals `src` in the
  same row (e.g. `gid` = `employee_id`). Same-table, same-row only.

### foreign_keys (single or composite)
- Single column:
  ```json
  { "from": "orders.customer_id", "to": "customers.customer_id" }
  ```
- Composite (referenced as a pair/tuple — integrity preserved, not sampled
  independently):
  ```json
  { "from": ["assignments.company_id", "assignments.employee_id"],
    "to":   ["employees.company_id", "employees.employee_id"] }
  ```
  All columns in one FK entry must belong to one child table and one parent
  table; `from` and `to` must be the same length.

### Cell resolution order
PK → FK → copy_columns → value_sets → unique → null-injection → Faker.

### Feasibility guards (script errors early, never loops forever)
- A `unique` column whose `value_set` has fewer distinct values than `rows`.
- A composite PK whose value space is too small to make `rows` unique tuples.


## How referential integrity works
- Parents are generated first; each child's FK value is drawn **only** from
  the parent's already-generated PK pool — no orphans.
- Every parent is guaranteed at least one child (requires child rows ≥ parent
  rows; otherwise you get a warning and coverage for as many as fit).
- Diamonds and long chains (region→store→customer→order→item) are supported.

## N-day slice mode
With `--days N`, the same business keys are emitted N times (one per day).
- One eligible column (non-PK, non-FK, non-audit) changes on each day after
  day 1. Pin it with `vary_column` or let it be random.
- Date-like audit columns (`pipeline_load_ts`, etc.) **advance +1 day per
  slice** automatically. Non-date audit constants stay fixed.
- Day 0 base date comes from `__base_date__`, else from a `*load*` audit
  constant, else today.

## Audit columns — how YOU control them
Any column whose name starts with `pipeline_` (configurable via
`--audit-prefix`) is treated as an audit column. It stays in its **original
DDL position** and is filled from `audit_constants`. Three ways to set them:

1. **Config constants (recommended)** — put the values in
   `audit_constants`. Date-like audit columns auto-advance per day-slice;
   everything else is the literal constant.
2. **Edit the CSV** — audit columns are in their schema position; find and
   overwrite the values.
3. **Stamp at load time in BigQuery** — leave/ignore the generated values and
   set them on insert:
   ```sql
   INSERT INTO `proj.ds.customers`
   SELECT
     * EXCEPT(pipeline_load_ts, pipeline_batch_id),
     CURRENT_TIMESTAMP()  AS pipeline_load_ts,
     'B20240115_0001'     AS pipeline_batch_id
   FROM staged_csv;
   ```

The script prints which columns it treated as audit and the values it used,
so you always know exactly what to override.

## CSV format (BigQuery-loadable)
- Header row; columns in exact DDL order.
- Empty cell = NULL (so BQ loads NULL, not the string "NULL").
- Booleans lowercase `true`/`false`.
- Nested/REPEATED fields = JSON strings.

## Load into BigQuery
```bash
bq load --source_format=CSV --skip_leading_rows=1 \
  project:dataset.customers ./out/customers.csv ./schemas/customers.json
```

## Sample included
`schemas/` + `relationships.json` produce the `out/` CSVs shown. Run with
`--days 2 --seed 42 --null-threshold 0.1` to reproduce exactly:
verified zero orphan FKs and every parent has ≥1 child.
