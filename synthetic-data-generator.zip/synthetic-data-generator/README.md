# Synthetic Data Generator for BigQuery Source Tables

Generates one CSV per BigQuery schema JSON, with cross-table referential
integrity, ready for `bq load`.

## Files
- `generate_synthetic.py` — the generator (single file, only dependency: `faker`).
- `relationships.json` — your per-run wiring (PKs, row counts, FKs, audit constants).
- `schemas/` — your BigQuery schema JSONs (one per table; filename = table name).
- `out/` — generated CSVs.

## Install & run
```bash
pip install faker
python generate_synthetic.py \
  --schemas ./schemas --config relationships.json --out ./out \
  --days 2 --seed 42 --null-threshold 0.1
```

## CLI flags
| Flag | Meaning | Default |
|---|---|---|
| `--schemas` | dir of BQ schema JSONs | required |
| `--config` | relationships.json | required |
| `--out` | output dir | `./out` |
| `--days` | day-slices: 1 = no history, 2 = two days, N = N days | 1 |
| `--seed` | reproducible output | none |
| `--null-threshold` | fraction of NULLABLE fields set to NULL (0..1) | 0.0 |
| `--null-mode` | `default` or `all-non-null` (force every field populated) | default |
| `--audit-prefix` | prefix that marks audit columns | `pipeline_` |

## relationships.json
```json
{
  "tables": {
    "customers":   { "pk": "customer_id",   "rows": 8 },
    "orders":      { "pk": "order_id",      "rows": 20 },
    "order_items": { "pk": "order_item_id", "rows": 40, "vary_column": "product_name" }
  },
  "foreign_keys": [
    { "from": "orders.customer_id",   "to": "customers.customer_id" },
    { "from": "order_items.order_id", "to": "orders.order_id" }
  ],
  "audit_constants": {
    "__base_date__": "2024-01-15",
    "pipeline_source_system": "WORKDAY",
    "pipeline_batch_id": "B20240115_0001"
  }
}
```
- `tables.<name>.rows` controls volume (1000–5000 fine). The parent/child
  ratio is implicit: set `customers.rows=10` and `orders.rows=3000` and each
  customer averages ~300 orders.
- `tables.<name>.days` overrides `--days` per table (optional).
- `tables.<name>.vary_column` pins which column changes across day-slices
  (optional; otherwise a random eligible column is chosen).
- `foreign_keys` is the only place relationships live — the script is fully
  generic and learns them here. Works for any number of tables; it
  topologically sorts so parents build before children and errors on cycles.

## How referential integrity works
- Parents are generated first; each child's FK value is drawn **only** from
  the parent's already-generated PK pool — no orphans.
- Every parent is guaranteed at least one child (requires child rows ≥ parent
  rows; otherwise you get a warning and coverage for as many as fit).
- Diamonds and long chains (region→store→customer→order→item) are supported.

## N-day slice mode
With `--days N`, the same business keys are emitted N times (one per day).
- One eligible column (non-PK, non-FK, non-audit) changes on each day after
  day 1. Pin it with `vary_column` or let it be random.
- Date-like audit columns (`pipeline_load_ts`, etc.) **advance +1 day per
  slice** automatically. Non-date audit constants stay fixed.
- Day 0 base date comes from `__base_date__`, else from a `*load*` audit
  constant, else today.

## Audit columns — how YOU control them
Any column whose name starts with `pipeline_` (configurable via
`--audit-prefix`) is treated as an audit column. It stays in its **original
DDL position** and is filled from `audit_constants`. Three ways to set them:

1. **Config constants (recommended)** — put the values in
   `audit_constants`. Date-like audit columns auto-advance per day-slice;
   everything else is the literal constant.
2. **Edit the CSV** — audit columns are in their schema position; find and
   overwrite the values.
3. **Stamp at load time in BigQuery** — leave/ignore the generated values and
   set them on insert:
   ```sql
   INSERT INTO `proj.ds.customers`
   SELECT
     * EXCEPT(pipeline_load_ts, pipeline_batch_id),
     CURRENT_TIMESTAMP()  AS pipeline_load_ts,
     'B20240115_0001'     AS pipeline_batch_id
   FROM staged_csv;
   ```

The script prints which columns it treated as audit and the values it used,
so you always know exactly what to override.

## CSV format (BigQuery-loadable)
- Header row; columns in exact DDL order.
- Empty cell = NULL (so BQ loads NULL, not the string "NULL").
- Booleans lowercase `true`/`false`.
- Nested/REPEATED fields = JSON strings.

## Load into BigQuery
```bash
bq load --source_format=CSV --skip_leading_rows=1 \
  project:dataset.customers ./out/customers.csv ./schemas/customers.json
```

## Sample included
`schemas/` + `relationships.json` produce the `out/` CSVs shown. Run with
`--days 2 --seed 42 --null-threshold 0.1` to reproduce exactly:
verified zero orphan FKs and every parent has ≥1 child.
